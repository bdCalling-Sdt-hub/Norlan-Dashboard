import React from "react";

const RentiPercentage = () => {
  return (
    <div>
      <h2>Renti Percentage</h2>
    </div>
  );
};

export default RentiPercentage;
